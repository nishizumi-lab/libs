# DatetimeExtender
his Python library can perform various calculations for datetime.  
このPythonライブラリは時刻の各種計算を行うことができます。

[Github](https://github.com/tanaka0079/libs/tree/master/python/datetime_extender-python)   
[Document](https://tanaka0079.github.io/libs/python/datetime_extender-python/docs/html/index.html)   

## Getting started（導入）
Install with `pip`.  
pipで簡単にインストールできます。

```
pip install util2 
```

## License（ライセンス）
This sample code is licensed under the MIT License.
サンプルコードはMITライセンスで公開しています。
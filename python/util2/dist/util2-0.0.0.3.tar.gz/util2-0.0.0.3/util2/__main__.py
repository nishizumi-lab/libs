from util2.util2 import main
from datetime.datetime import Datetime

def main():
    print("OK")

if __name__ == "__main__":
    main()

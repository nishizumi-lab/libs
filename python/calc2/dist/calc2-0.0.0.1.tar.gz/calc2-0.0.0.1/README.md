# electrical
his Python library can perform various calculations for electrical systems.  
このPythonライブラリは電気系の各種計算を行うことができます。
  
[Document](https://nishizumi-lab.github.io/libs/python/electrical-python/docs/html/index.html)   

## Getting started（導入）
Install with `pip`.  
pipで簡単にインストールできます。

```
pip install electrical
```

## License（ライセンス）
This sample code is licensed under the MIT License.
サンプルコードはMITライセンスで公開しています。
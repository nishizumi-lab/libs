# -*- coding: utf-8 -*-

"""Top-level package for electrical."""

__author__ = """Nishizumi"""
__email__ = 'daiman003@yahoo.co.jp'
__version__ = '0.2'
